import os
from sentence_transformers import SentenceTransformer, InputExample, losses
from torch.utils.data import DataLoader
import pandas as pd

# Function to load data
def load_data_from_csv(csv_path):
    df = pd.read_csv(csv_path)
    context = df['context'].tolist()
    question = df['question'].tolist()
    return context, question

# Function to train the SBERT model
def train_sbert_model(context, question, model_name='all-MiniLM-L6-v2', output_path='output/fine_tuned_sbert_model'):

    train_examples = [InputExample(texts=[c, q]) for c, q in zip(context, question)]

    model = SentenceTransformer(model_name)


    train_dataloader = DataLoader(train_examples, shuffle=True, batch_size=16)


    train_loss = losses.MultipleNegativesRankingLoss(model)


    model.fit(train_objectives=[(train_dataloader, train_loss)], epochs=3, warmup_steps=100)

    # Saving the model
    os.makedirs(output_path, exist_ok=True)
    model.save(output_path)
    print(f"Model saved to {output_path}")
    return model

# Function to load the SBERT model
def load_finetuned_sbert_model():
    model_path = os.path.join(os.path.dirname(__file__), 'output', 'fine_tuned_sbert_model')

    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model path does not exist: {model_path}")

    # Load the model
    model = SentenceTransformer(model_path)
    return model


if __name__ == "__main__":
    import os

    csv_path = os.path.join(os.path.dirname(__file__), '..', 'sbert_training_data.csv')
    context, question = load_data_from_csv(csv_path)
    model = train_sbert_model(context, question)  # Train the model
