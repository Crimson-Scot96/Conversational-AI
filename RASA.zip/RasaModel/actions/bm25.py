import pandas as pd
import ast
import re
import numpy as np
from sentence_transformers import SentenceTransformer, util
from rank_bm25 import BM25Okapi


# Tokenize and lowercase, remove punctuation
def tokenize(text):
    text = re.sub(r"[^\w\s]", "", text.lower())  # Remove punctuation and lowercase
    return text.split()


# Load dataset and prepare BM25
def load_bm25(csv_file):
    df = pd.read_csv(csv_file)

    all_summaries = []
    tokenised_summaries = []

    for idx, row in df.iterrows():
        try:
            summaries = ast.literal_eval(row["summaries"])  # Assuming the summaries column contains a list
            for summary in summaries:
                if isinstance(summary, str):
                    all_summaries.append(summary)
                    tokenised_summaries.append(tokenize(summary))
        except:
            continue

    # Initialize BM25
    bm25 = BM25Okapi(tokenised_summaries)
    return bm25, all_summaries


# Load SentenceTransformer model for reranking
def load_model():
    model = SentenceTransformer("all-MiniLM-L6-v2")
    return model


# Retrieve summary using BM25 and reranking with SBERT
def retrieve_summary(query, bm25, all_summaries, model, bm25_top_n=5, confidence_threshold=0.40):
    tokenised_query = tokenize(query)
    bm25_scores = bm25.get_scores(tokenised_query)

    top_indices = np.argsort(bm25_scores)[-bm25_top_n:][::-1]
    top_summaries = [all_summaries[i] for i in top_indices]

    # Rerank using SBERT
    query_embedding = model.encode(query, convert_to_tensor=True)
    top_embeddings = model.encode(top_summaries, convert_to_tensor=True)
    cosine_similarities = util.cos_sim(query_embedding, top_embeddings)[0].cpu().numpy()

    # Confidence check (SBERT's rerank score)
    top_score = max(cosine_similarities)

    if top_score < confidence_threshold:
        return "not confident"

    best_index = np.argmax(cosine_similarities)
    return top_summaries[best_index]
