import sys
import os
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from actions.bm25 import load_bm25, retrieve_summary  # Import BM25 functions from bm25.py
import logging
import pandas as pd
from sentence_transformers import SentenceTransformer, util
from actions.finetuned_sbert import load_finetuned_sbert_model # Importing the load_finetuned_sbert_model function from finetuned_sbert.py in actions folder


# Load BM25 and SBERT model once
bm25, all_summaries = load_bm25("raw_outputs.csv")
model = load_finetuned_sbert_model()

class ActionRouteToBM25(Action):
    def name(self) -> str:
        return "action_route_to_bm25"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: dict) -> list:

        # Get the user query
        query = tracker.latest_message.get('text')

        # Log the query and intent for debugging
        intent = tracker.latest_message['intent'].get('name')
        logging.debug(f"Received query: {query}")
        logging.debug(f"Detected intent: {intent}")

        try:

            top_summary = retrieve_summary(query, bm25, all_summaries, model)

            if top_summary == "not confident":
                # If BM25 is not confident, ask a clarifying question using SBERT
                clarifying_question = self.generate_clarifying_question(query)
                dispatcher.utter_message(text=clarifying_question)
            else:
                # return the top-ranked summary if confident
                dispatcher.utter_message(text=top_summary)

        except Exception as e:
            # Logs incase error
            dispatcher.utter_message(text="Sorry, I couldn't find an answer.")
            logging.error(f"Error: {e}")

        return []

    def generate_clarifying_question(self, query):

        # Load dataset
        clarifications_df = pd.read_csv('sbert_training_data.csv')
        clarifications = clarifications_df['question'].tolist()


        query_emb = model.encode(query, convert_to_tensor=True)


        clarification_embs = model.encode(clarifications, convert_to_tensor=True)


        similarities = util.pytorch_cos_sim(query_emb, clarification_embs)[0].cpu().numpy()


        best_clarification_index = similarities.argmax()

        return clarifications[best_clarification_index]
